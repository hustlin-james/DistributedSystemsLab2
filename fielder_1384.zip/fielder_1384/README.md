# DistributedSystemsLab2
James Fielder 
1000631384

Ring Network Election Algorithm

Needs Linux Environment to run.
To Run: python ring.py

This lab contains the Extra Credit for GUI using Tkinter.
Note: clicking Run 2 Elections will logically spawn another token being *passed* around, basically
creating another simulation.

References:
https://www.tutorialspoint.com/python/
https://wiki.python.org/moin/TkInter